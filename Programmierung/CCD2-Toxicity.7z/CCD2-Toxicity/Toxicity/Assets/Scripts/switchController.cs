﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class switchController : MonoBehaviour {

    public string targetTag;
    private bool off = true;
    TrapController trap;
	// Use this for initialization
	void Start () {
       trap = GameObject.FindGameObjectWithTag("Trap lightning").GetComponent<TrapController>();

    }

    // Update is called once per frame
    void OnTriggerStay(Collider push)
    {
        if (push.gameObject.tag == "Player" && targetTag == "Player")
        {
            if (Input.GetKeyDown("e"))
            {
                trap.trapoff(off);
            }
        }
	}
}

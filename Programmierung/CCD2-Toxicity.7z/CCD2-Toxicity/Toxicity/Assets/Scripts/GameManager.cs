﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public static GameManager instance = null;
    public GameObject player;

	// Use this for initialization
	void Awake() {
		if(instance == null)
        {
            instance = this;
        }else if(instance != this)
        {
            Destroy(this);
        }
        //StartCoroutine(Config());
        
	}

    /*IEnumerator Config()
    {
        do
        {
            yield return new WaitForSeconds(0.2f);
            //Do whatever needed
        } while (xxxx);
    }*/
	
}

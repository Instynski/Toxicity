﻿

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{

    public Transform spawnPoint;
    public Transform bullet;
    public Transform player;
    private Rigidbody myRB;
    public float moveSpeed;
    public PlayerController thePlayer;
    public bool reddynow;

    // Use this for initialization
    void Start()
    {
        myRB = GetComponent<Rigidbody>();
        thePlayer = FindObjectOfType<PlayerController>();
        reddynow = true;
    }

    void goEnemy()
    
        {
            myRB.velocity = (transform.forward * moveSpeed);
        }
  
    // Update is called once per frame
    void Update()
    {
        var playerDistance = Vector3.Distance(this.transform.position, player.position);
        if (playerDistance <= 6)
        {
            transform.LookAt(player.transform);
            if (reddynow)
            {
                StartCoroutine(makeBullet());
            }
        }
        if(playerDistance <= 10 && playerDistance >=6)
        {
           goEnemy();
        }
     }

    IEnumerator makeBullet()
    {
        reddynow = false;
        yield return new WaitForSeconds(1.0f);
        Instantiate(bullet, spawnPoint.position, spawnPoint.rotation);
        reddynow = true;
    }
}


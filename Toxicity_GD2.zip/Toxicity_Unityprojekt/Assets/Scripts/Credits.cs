﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Credits : MonoBehaviour {

    // Methode für klicken auf dem Start Button, sucht und ladet die Scene des Spiels
    public void LoadScene(string Back)
    {
        SceneManager.LoadScene(0);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightningTrap : MonoBehaviour
{

    public float playerdamageToGive;
    public string targetTag;

    void OnTriggerStay(Collider hit)
    {
        if (hit.gameObject.tag == "Player" && targetTag == "Player")
        {
            hit.gameObject.GetComponent<PlayerHealth>().HurtPlayer(playerdamageToGive * Time.fixedDeltaTime);
        }
    }
}

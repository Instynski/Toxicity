﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class KeyController : MonoBehaviour {

    private int numberKeys;

    // Use this for initialization
    void Start ()
    {
        numberKeys = 0;
	}
    public void AddKey()
    {
        numberKeys++;
    }
    public void useKey()
    {
        numberKeys--;
    }
    public int getKeys()
    {
        return numberKeys;
    }
}

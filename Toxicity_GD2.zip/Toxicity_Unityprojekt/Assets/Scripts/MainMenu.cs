﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    // Methode für klicken auf dem Start Button, sucht und ladet die Scene des Spiels
    public void LoadScene(string Start)
    {
        SceneManager.LoadScene(1, LoadSceneMode.Single);
    }
    //  Methode für klicken auf dem Exit Button beendet das Spiel
    public void ExitSpiel()
    {
        Application.Quit();
    }
}
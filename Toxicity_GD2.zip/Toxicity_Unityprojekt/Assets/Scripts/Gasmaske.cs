﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gasmaske : MonoBehaviour {

    public float dmgReduction;
    private GameObject PoisonGas;

    private void Start()
    {
        PoisonGas = GameObject.FindWithTag("Trap Gas");
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            GameObject.Find("PlayerMask").GetComponentInChildren<MeshRenderer>().enabled = true;
            PoisonGas.GetComponent<PoisonGas>().setDmgReduction(dmgReduction);
            Destroy(gameObject);
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrapSwitch : MonoBehaviour {

    private Animator an;
    private ParticleSystem funken1a;
    private ParticleSystem funken1b;
    private ParticleSystem funken2a;
    private Collider falle1;
    private Collider falle2;
	// Use this for initialization
	void Start () {
        an = this.GetComponent<Animator>();
        funken1a = GameObject.Find("Funken1a").GetComponent<ParticleSystem>();
        funken1b = GameObject.Find("Funken1b").GetComponent<ParticleSystem>();
        funken2a = GameObject.Find("Funken2a").GetComponent<ParticleSystem>();
        falle1 = GameObject.Find("Falle 1").GetComponent<Collider>();
        falle2 = GameObject.Find("Falle 2").GetComponent<Collider>();
	}

    private void OnTriggerStay(Collider other)
    {
        if(other.gameObject.tag == "Player")
        {
            if (Input.GetKeyDown("e"))
            {
                an.Play("aus", -1, 0f);
                falle1.enabled = false;
                falle2.enabled = false;
                funken1a.Stop();
                funken1b.Stop();
                funken2a.Stop();
            }
        }
    }
}

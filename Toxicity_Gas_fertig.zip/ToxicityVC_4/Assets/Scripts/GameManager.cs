﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour {

    public static GameManager instance = null;
    public GameObject player;
    public int PauseOnDeath;

	// Use this for initialization
	void Awake() {
		if(instance == null)
        {
            instance = this;
        }else if(instance != this)
        {
            Destroy(this);
        }
        //StartCoroutine(Config());
        
	}

    public void dead()
    {
        StartCoroutine("End");
    }

    IEnumerator End()
    {
        Destroy(player);
        yield return new WaitForSeconds(PauseOnDeath);
        SceneManager.LoadScene(2, LoadSceneMode.Single);
    }

    /*IEnumerator Config()
    {
        do
        {
            yield return new WaitForSeconds(0.2f);
            //Do whatever needed
        } while (xxxx);
    }*/
	
}

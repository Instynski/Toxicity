﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoisonGas : MonoBehaviour
{

    public float damage;
    private float dmgReduction;
    private GameObject player;

    private void Start()
    {
        dmgReduction = 1;
    }

    private void OnParticleTrigger()
    {
        player = GameObject.FindWithTag("Player");
        ParticleSystem ps = GetComponent<ParticleSystem>();
        List<ParticleSystem.Particle> inside = new List<ParticleSystem.Particle>();
        int numInside = ps.GetTriggerParticles(ParticleSystemTriggerEventType.Inside, inside);
        if(numInside > 0)
        {
            player.gameObject.GetComponent<PlayerHealth>().HurtPlayer(damage*dmgReduction);
        }
        ps.SetTriggerParticles(ParticleSystemTriggerEventType.Inside, inside);
    }

    public void setDmgReduction(float x)
    {
        dmgReduction = x;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Door : MonoBehaviour {

    private int numberKeys;
    public bool isFinal;
	
    void OnTriggerStay(Collider push)
    {
        numberKeys = push.GetComponent<KeyController>().getKeys();
        if (push.gameObject.tag == "Player")
        {
            if (Input.GetKeyDown("e") && numberKeys > 0)
            {
                push.GetComponent<KeyController>().useKey();
                if (!isFinal)
                {
                    Destroy(gameObject);
                }
                else
                {
                    SceneManager.LoadScene(2, LoadSceneMode.Single);
                }
            }
        }
    }
}

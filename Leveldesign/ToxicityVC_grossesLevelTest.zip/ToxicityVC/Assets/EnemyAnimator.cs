﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAnimator : MonoBehaviour
{

    Animator an;
    AnimatorStateInfo StateInfo;
    int layer;
    float inputV;
    float inputH;

    void Start()
    {
        an = this.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        inputV = Input.GetAxis("Vertical");
        inputH = Input.GetAxis("Horizontal");

        an.SetFloat("inputH", inputH);
        an.SetFloat("inputV", inputV);
    }
}

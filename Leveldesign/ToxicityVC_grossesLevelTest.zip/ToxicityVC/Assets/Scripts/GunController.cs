﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunController : MonoBehaviour {

    public bool isFiring;

    public BulletController bullet;
    public float bulletspeed;

    [Range(0.1f, 2f)]
    public float timeBetweenShots;
    private float shotCounter;

    public Transform firePoint;

    public string targetTag;

    Animator an;

    private void Start()
    {
        an = GetComponentInParent<Animator>();
    }

    public void fireBullet()
    {
        if (shotCounter < Time.time)
        {
            an.Play("schuss_dummy");
            shotCounter = Time.time + timeBetweenShots;
            BulletController newBullet = Instantiate(bullet, firePoint.position, firePoint.rotation) as BulletController;
            newBullet.speed = bulletspeed;
            Debug.Log(this.targetTag);
            newBullet.targetTag = this.targetTag;
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class PlayerHealth : MonoBehaviour
{
    public float maxHealth = 10;
    public float playerhealth;
    private float playercurrentHealth;
    private float update;
    private GameObject canvas;




    // Use this for initialization
    void Start()
    {
        canvas = GameObject.Find("Canvas");
        playercurrentHealth = playerhealth;
        UpdateView();
    }

    // Update is called once per frame
    public void HurtPlayer(float playerdamage)
    {

        playercurrentHealth -= playerdamage;
        Debug.Log(playercurrentHealth);

        if (playercurrentHealth <= 0)
        {
            Destroy(gameObject);
        }
        UpdateView();
    }

    public void AddHealth(float extraHealth)
    {

        playercurrentHealth += extraHealth;

        playercurrentHealth = Mathf.Min(playercurrentHealth, maxHealth);
        Debug.Log(playercurrentHealth);
        UpdateView();
    }



    //UI Aktuallisierung
    public void UpdateView()
    {
        update = playercurrentHealth / maxHealth;
        canvas.GetComponentInChildren<HealthBarScript>().fillAmount = update;
    }


}
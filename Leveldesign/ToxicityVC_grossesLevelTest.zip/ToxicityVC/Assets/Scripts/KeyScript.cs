﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyScript : MonoBehaviour 
{
    KeyController key;

    // Use this for initialization
    void Start()
    {
        key = GameObject.FindGameObjectWithTag("KeyDoor").GetComponent<KeyController>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            key.AddKey(true);
            Destroy(gameObject);
        }
    }
}


﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyController : MonoBehaviour {

    public bool hasKey;
    public string targetTag;

    // Use this for initialization
    void Start ()
    {
        hasKey = false;
	}
	
	// Update is called once per frame
    void OnTriggerStay(Collider push)
    {
        if (push.gameObject.tag == "Player" && targetTag == "Player")
        {
            if (Input.GetKeyDown("e") && hasKey == true)
            {
                Destroy(gameObject);
            }
        }
    }
    public void AddKey(bool key)
    {
        //Debug.Log(key);
        hasKey = key;
    }
}

﻿

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{

    public Transform spawnPoint;
    GameObject player;
    Transform playerTransform;
    private Rigidbody myRB;
    public float moveSpeed;
    public PlayerController thePlayer;
    public GunController theGun;

    private Animator an;


    // Use this for initialization
    void Start()
    {
        an = this.GetComponent<Animator>();
        myRB = GetComponent<Rigidbody>();
        StartCoroutine(Config());
    }
    
    IEnumerator Config()
    {
        while(GameManager.instance == null)
        {
            yield return new WaitForSeconds(0.2f);
        }
        while(GameManager.instance.player == null)
        {
            yield return new WaitForSeconds(0.2f);
        }
        player = GameManager.instance.player;
        playerTransform = player.transform;
        thePlayer = player.GetComponent<PlayerController>();
        StartCoroutine(UpdateEnemy());
    }

    void goEnemy()
    
        {
            myRB.velocity = (transform.forward * moveSpeed);
        }

    IEnumerator UpdateEnemy()
    {
        while (player.activeInHierarchy)
        {
            var playerDistance = Vector3.Distance(this.transform.position, playerTransform.position);
            while (playerDistance <= 10)
            {
                playerDistance = Vector3.Distance(this.transform.position, playerTransform.position);
                if (playerDistance <= 6)
                {
                    transform.LookAt(playerTransform);
                    theGun.fireBullet();
                }
                if (playerDistance >= 6)
                {
                    an.SetBool("IsIdle", false);
                    an.SetBool("IsWalking", true);
                    goEnemy();
                }
                yield return null;
            }
            yield return new WaitForSeconds(0.2f);
        }
        an.SetBool("IsIdle", true);
        an.SetBool("IsWalking", false);
        
    }
}


﻿using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float movespeet;
    private Rigidbody myrigi;

    private Vector3 moveInput;
    private Vector3 movevelocity;

    private Camera mainCamera;

    public GunController theGun;

    private Animator an;
    private float inputV;
    private float inputH;

    // Use this for initialization
    void Start () {
        an = this.GetComponent<Animator>();
        myrigi = GetComponent<Rigidbody>();
        mainCamera = FindObjectOfType<Camera>();
        GameManager.instance.player = this.gameObject;
	}
	
	// Update is called once per frame
	void Update () {
        moveInput = new Vector3(Input.GetAxisRaw("Horizontal"), 0f, Input.GetAxisRaw("Vertical"));
        movevelocity = moveInput * movespeet;

        inputV = moveInput.z;
        inputH = moveInput.x;
        an.SetFloat("inputV", inputV);
        an.SetFloat("inputH", inputH);

        Ray cameraRay = mainCamera.ScreenPointToRay(Input.mousePosition);
        Plane groundPlane = new Plane(Vector3.up, Vector3.zero);
        float rayLength;

        if(groundPlane.Raycast(cameraRay, out rayLength))
        {
            Vector3 pointToLook = cameraRay.GetPoint(rayLength);
            Debug.DrawLine(cameraRay.origin, pointToLook, Color.blue);

            transform.LookAt(new Vector3(pointToLook.x, transform.position.y, pointToLook.z));
        }

        if (Input.GetMouseButtonDown(0))
        {
            theGun.fireBullet();
        }
	}

    void FixedUpdate()
    {
        myrigi.velocity = movevelocity;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrapController : MonoBehaviour
{

    public float playerdamageToGive;
    public string targetTag;
    
    void OnTriggerStay(Collider hit)
    {
        if (hit.gameObject.tag == "Player" && targetTag == "Player")
        {
            hit.gameObject.GetComponent<PlayerHealth>().HurtPlayer(playerdamageToGive*Time.fixedDeltaTime);
        }
    }
public void trapoff(bool off)
    {
        if(off == true)
        Destroy(gameObject);
    }    
}
